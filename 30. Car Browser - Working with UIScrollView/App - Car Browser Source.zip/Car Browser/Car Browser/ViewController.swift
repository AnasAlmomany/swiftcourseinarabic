//
//  ViewController.swift
//  Car Browser
//
//  Created by Anas Almomany on 5/15/20.
//  Copyright © 2020 plaster. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

