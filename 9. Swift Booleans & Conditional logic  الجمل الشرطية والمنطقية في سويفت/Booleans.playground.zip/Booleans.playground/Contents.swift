import UIKit

// If condition Then doSomething , Else doAnotherThing
// condition -> Bool

// Bool -> Data type (true, false)

var isItRaining: Bool = false

if isItRaining {
    print("Wear Hat")
} else {
    print("dont wear anyhthing")
}

// Operators :
// Equal to ==
// Not Equal to !=
// Or ||
// Greater Than >
// Greater Than or equal to >=
// Less Than <
// Less Than or equal to <=

if true == false || true == true {
    
}

let itemPrice = 100
let walletTotal = 50

if itemPrice <= walletTotal {
    print("You can buy this item")
} else {
    print("You are broke! ")
}

var employeeName = "Anas Almomany"
var myName = "Anas Almomany"

let conditionRslt = (employeeName == myName)
if conditionRslt {
    print("Same Guy!")
} else {
    print("Not the Same Guy!")
}

