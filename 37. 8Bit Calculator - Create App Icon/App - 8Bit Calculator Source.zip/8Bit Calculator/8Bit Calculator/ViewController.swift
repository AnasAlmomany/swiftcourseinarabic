//
//  ViewController.swift
//  8Bit Calculator
//
//  Created by Anas Almomany on 5/25/20.
//  Copyright © 2020 plaster. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    enum Operation: Int {
        case divide = 0, multiply, subtract, add, cleared
        
        var name: String {
            switch self {
            case .divide:
                return "divide"
            case .multiply:
                return "multiply"
            case .subtract:
                return "subtract"
            case .add:
                return "add"
            case .cleared:
                return "cleared"
            }
        }
    }

    @IBOutlet weak var resultLabel: UILabel!
    
    var btnSound: AVAudioPlayer!
    var bgMusic: AVAudioPlayer!

    var activeNumberStr = ""
    var currentOp = Operation.cleared
    var leftValue = ""
    var rightValue = ""
    
    var result = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupBGSound()
        setupTapSound()
    }
    
    func setupTapSound(){
        let path = Bundle.main.path(forResource: "tap", ofType: "wav")
        let url = URL(fileURLWithPath: path!)
        
        do {
            try btnSound = AVAudioPlayer(contentsOf: url)
            btnSound.prepareToPlay()
        } catch _ {
            print(" Error loaing sound ")
        }
    }
    
    func playTapSound(){
        if btnSound.isPlaying {
            btnSound.stop()
        }
        btnSound.play()
    }
    
    func setupBGSound(){
        let path = Bundle.main.path(forResource: "bg-music", ofType: "mp3")
        let url = URL(fileURLWithPath: path!)
        
        do {
            try bgMusic = AVAudioPlayer(contentsOf: url)
            bgMusic.play()
        } catch _ {
            print(" Error loaing sound ")
        }
    }
    
    @IBAction func numberTapped(_ sender: UIButton) {
        playTapSound()
        
        activeNumberStr += "\(sender.tag)"
        resultLabel.text = activeNumberStr
    }
    
    @IBAction func operationTapped(_ sender: UIButton) {
        let op = Operation(rawValue: sender.tag) ?? .cleared
        
        computeOperation(op: op)
    }
    
    @IBAction func equalTapped(_ sender: UIButton) {
        
        computeOperation(op: currentOp)
    }
    
    // [1] - [Operation] - [1] = [??]
    func computeOperation(op: Operation) {
        playTapSound()
        
        if currentOp == .cleared {
            // First time operater tapped
            leftValue = activeNumberStr
            currentOp = op
             
            activeNumberStr = "" // Reset
        } else {
            if !activeNumberStr.isEmpty {
                rightValue = activeNumberStr
                activeNumberStr = "" // Reset
                
                if currentOp == .multiply {
                    result = "\( Double(leftValue)! * Double(rightValue)!)"
                } else if currentOp == .divide {
                    result = "\( Double(leftValue)! / Double(rightValue)!)"
                } else if currentOp == .add {
                    result = "\( Double(leftValue)! + Double(rightValue)!)"
                } else if currentOp == .subtract {
                    result = "\( Double(leftValue)! - Double(rightValue)!)"
                }
                
                leftValue = result
                resultLabel.text = result
            }
            
            currentOp = op
        }
    }
}

