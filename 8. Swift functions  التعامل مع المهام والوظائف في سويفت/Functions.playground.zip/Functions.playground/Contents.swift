import UIKit

var str = "Hello, playground"

// Shape 1
var length = 5
var width = 10

var area = length * width

// Shape 2
var length2 = 9
var width2 = 10

var area2 = length2 * width2

// Shape 3
var length3 = 54
var width3 = 20

var area3 = length3 * width3


func calculateArea(length: Int, width: Int) -> Int {
    return length * width
}

let newArea = calculateArea(length: 5, width: 10)
let newArea2 = calculateArea(length: 9, width: 10)
let newArea3 = calculateArea(length: 54, width: 20)


var salaryBalance = 500.0
var ball = 20.0

func purshaseItem(currentBalance: inout Double, itemPrice: Double){
    if itemPrice <= currentBalance {
        print("You have purchased this item with a price of \(itemPrice)")
        currentBalance = currentBalance - itemPrice
    } else {
        print("You are very broke !! go get a job !")
    }
}

purshaseItem(currentBalance: &salaryBalance, itemPrice: ball)

print(salaryBalance)


