import UIKit

class Animal {
    var numberOfLegs = 4
    var home = ""

    func walk(){
        
    }
    
    func jump(){
        
    }
}

let cat = Animal() // Object / Instance
cat.jump()
cat.walk()
cat.home = "USA"

let kangaro = Animal() // Object / Instance
kangaro.jump()
kangaro.walk()
kangaro.home = "Austrailia"

let kangaro1 = kangaro
kangaro1.home = "China"

print(kangaro.home)
print(kangaro1.home)

func editHomeLand(animal: Animal){
    animal.home = "russa"
}

editHomeLand(animal: cat)

print(cat.home)

let num = 5


