//
//  ViewController.swift
//  MagicBakery
//
//  Created by Anas Almomany on 5/9/20.
//  Copyright © 2020 plaster. All rights reserved.
//

import UIKit

struct OrderDetailsData {
    var fullname: String
    var addressText: String
    var orderText: String
    var countryBranch: String
}

class FirstScreenViewController: UIViewController {
    // Interface Builder Outlet
    @IBOutlet weak var fullNameTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var orderTextField: UITextField!
    @IBOutlet weak var selectBranchButton: UIButton!
    @IBOutlet weak var countryPickerView: UIPickerView!
    @IBOutlet weak var submitButton: UIButton!
    
    let branchesArray = ["Jordan", "UAE", "Saudi Arabia", "Lebanon"]
    var selectedBranchName = ""
        
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addGestureRecognizer(UITapGestureRecognizer(target: view, action: #selector(UIView.endEditing(_:))))
        
        submitButton.alpha = 0.3
        submitButton.isUserInteractionEnabled = false
        
        countryPickerView.isHidden = true
        countryPickerView.delegate = self
        countryPickerView.dataSource = self
    }
    
    @IBAction func selectBranchTapped(_ sender: UIButton) {
        countryPickerView.isHidden = false
    }
    
    @IBAction func sumbitOrderTapped(_ sender: UIButton) {
        
        let orderDetailes = OrderDetailsData(fullname: fullNameTextField.text!, addressText: addressTextField.text!, orderText: orderTextField.text!, countryBranch: selectedBranchName)
        print(orderDetailes)

        let controller = storyboard?.instantiateViewController(identifier: "SecoundScreenViewController") as! SecoundScreenViewController
        controller.orderDetails = orderDetailes
        present(controller, animated: true, completion: nil)
    }
    
}

// Population for date picker
extension FirstScreenViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return branchesArray.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return branchesArray[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print("didSelectRow: \(row) inComponent \(component)")
        selectedBranchName = branchesArray[row]
        selectBranchButton.setTitle(selectedBranchName, for: .normal)
        
        submitButton.alpha = 1
        submitButton.isUserInteractionEnabled = true
    }
}
