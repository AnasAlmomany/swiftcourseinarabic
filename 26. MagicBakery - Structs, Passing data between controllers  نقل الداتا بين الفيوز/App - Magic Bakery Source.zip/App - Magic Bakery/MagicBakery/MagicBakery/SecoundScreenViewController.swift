//
//  SecoundScreenViewController.swift
//  MagicBakery
//
//  Created by Anas Almomany on 5/9/20.
//  Copyright © 2020 plaster. All rights reserved.
//

import UIKit

class SecoundScreenViewController: UIViewController {
    @IBOutlet weak var thanksMsgLabel: UILabel!
    @IBOutlet weak var orderDetailesMsgLabel: UILabel!
    
    var orderDetails: OrderDetailsData!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        thanksMsgLabel.text = "Thanks \(orderDetails.fullname) for ordering !"
        orderDetailesMsgLabel.text = "\(orderDetails.countryBranch) Branch will deliver your order \" \(orderDetails.orderText) \" to \(orderDetails.addressText) soon !!"
    }
}
