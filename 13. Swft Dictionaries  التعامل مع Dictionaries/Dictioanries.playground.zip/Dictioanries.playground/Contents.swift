import UIKit

var names = [Int : String]()  // Init Dic

// Assigning for the key value
names[2] = "Anas"
names[44] = "Moe"

//print(names[2])

names = [:]

/// Postal codes/ Zip codes , ex: A = 1 , B = 2 , C = 1

var postalCodes: [String: String] = ["Amman" : "1234", "Dubai" : "214324", "USA" : "3333"]

if postalCodes.isEmpty {
    print("No postal codes available")
}

postalCodes["Amman"] = "99999"
postalCodes["Amman"] = "99991"

postalCodes["Dubai"] = nil

///
for (key, value) in postalCodes {
    print("\(key) have postal code of \(value)")
}

for key in postalCodes.keys {
    print("\(key) have postal code!")
}

for values in postalCodes.values {
    print("\(values) is a postal code!")
}
