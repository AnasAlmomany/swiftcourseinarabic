import UIKit

/// Guardian of the Mall - Access Application اسخف نظام حماية بالعالم
// Technical Requirements
// 1- Manager can always enter at any time
// 2- Employees shoud scan face
// 3- Employees shoud enter code
// 4- Print "Access denied" for not allowed users
// 5- Print "You can access" for allowed users

// Logical Operators - in action

// Employee X
let enteredDoorCode = true
let passedFaceScan = false

let iamAManager = false

if enteredDoorCode && passedFaceScan || iamAManager {
    print("You can access")
} else {
    print("Access denied")
}
