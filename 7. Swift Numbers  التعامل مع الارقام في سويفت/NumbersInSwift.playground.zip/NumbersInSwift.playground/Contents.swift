import UIKit

var str = "Hello, playground"

var intNumber: Int = 12
intNumber = 32432434567654567
intNumber = 105

var smallInt: UInt8 = 231

var doubleNumber = 200.4
doubleNumber = 345678976545678996537344
doubleNumber = 10.5

var pi: Float = 3.14
var anotherFloat = pi

// Int , UInt8 , Double, Float

// Arithemitc Operators
// * - / +

var area = 12 * 15

var sum = 55 + 10

var diff = 55 - 16

var div = 12 / 3

var div2 = 13 / 5

var rem = 13 % 5

var result = "The res of 13 / 5 is \(div2) and a remainder of \(rem)"

var randomNumber = 13

if randomNumber % 2 == 0 {
    print("this is even")
} else {
    print("this is odd")
}

var result2: Double = 10.0 * ((5.0+7.0) / 3.0)

























