//
//  WeatherCellTableViewCell.swift
//  Sunny Days
//
//  Created by Anas Almomany on 6/6/20.
//  Copyright © 2020 plaster. All rights reserved.
//

import UIKit
import Kingfisher

struct WeatherDailyData {
    var iconName: String
    var dateName: String
    var weatherType: String
    var tempMin: String
    var tempMax: String
}

class WeatherCell: UITableViewCell {
    static var id = "WeatherCell"
    
    @IBOutlet weak var imgBgView: UIView!
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var weatherTypeLable: UILabel!
    @IBOutlet weak var tempMaxLabel: UILabel!
    @IBOutlet weak var tempMinLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()

        imgBgView.layer.cornerRadius = imgBgView.frame.height/2
    }
    
    func configre(_ data: WeatherDailyData){
        dateLabel.text = data.dateName
        weatherTypeLable.text = data.weatherType
        tempMaxLabel.text = "\(data.tempMax)°"
        tempMinLabel.text = "\(data.tempMin)°"
        
        downloadImage(imageName: data.iconName)
    }
    
    func downloadImage(imageName: String) {
        let path = iconsPath.replacingOccurrences(of: "##", with: imageName)
        let url = URL(string: path)
        iconImageView.kf.setImage(with: url)
    }
}
