//
//  ViewController.swift
//  Sunny Days
//
//  Created by Anas Almomany on 6/6/20.
//  Copyright © 2020 plaster. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController {
    
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var weatherTypeLabel: UILabel!
    @IBOutlet weak var placeNameLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var weatherIconImageView: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    let locationManager = CLLocationManager()
    var currentLocation: CLLocationCoordinate2D!
    
    var dailyData: [WeatherDailyData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupLocation()
        setupTableView()
        weatherIconImageView.layer.cornerRadius = 15
    }
    
    func setupLocation(){
        switch CLLocationManager.authorizationStatus() {
        case .notDetermined,.restricted,.denied:
            return
        case .authorizedAlways,.authorizedWhenInUse:
            locationManager.delegate = self
            locationManager.requestWhenInUseAuthorization()
            locationManager.startMonitoringSignificantLocationChanges()
        @unknown default:
            print("Nothing")
        }
    }
    
    func loadWeather(for location: Location) {
        WeatherApi.shared.callWeatherApi(location: location) { (weatherData) in
            if let weatherData = weatherData {
                self.updateTodayWeather(data: weatherData)
            }
        }
        
        WeatherApi.shared.callDailyForcastApi(location: location) { (forcatData) in
            if let forcasts = forcatData?.forcasts {
                self.updateDailyForcast(forcasts: forcasts)
            }
        }
    }
    
    func updateTodayWeather(data: WeatherDetailsData){
        tempLabel.text = "\(data.main?.temp ?? 0)°"
        weatherTypeLabel.text = data.weather?.first?.main
        placeNameLabel.text = data.name

        let dateFormater = DateFormatter()
        dateFormater.dateStyle = .medium
        dateFormater.timeStyle = .none
        
        let currentDateRep = dateFormater.string(from: Date())
        dateLabel.text = "Today, \(currentDateRep)"
        
        if let imageName = data.weather?[0].icon {
            downloadImage(imageName: imageName)
        }
    }
    
    func downloadImage(imageName: String) {
        let path = iconsPath.replacingOccurrences(of: "##", with: imageName)
        let url = URL(string: path)
        weatherIconImageView.kf.setImage(with: url)
    }
    
    func updateDailyForcast(forcasts: [Forcast]){
        let daysData: [WeatherDailyData] = forcasts.map { (forcast) -> WeatherDailyData in
            
            var minTemp = ""
            if let kelvinTemp = forcast.temp?.min {
                let celsiusTemp = kelvinTemp - 273.15
                minTemp = String(format: "%.0f", celsiusTemp)
            }
            
            var maxTemp = ""
            if let kelvinTemp = forcast.temp?.max {
                let celsiusTemp = kelvinTemp - 273.15
                maxTemp = String(format: "%.0f", celsiusTemp)
            }
             
            let type = forcast.weather?.first?.main ?? ""
            let iconName = forcast.weather?.first?.icon ?? ""
            
            var dateString = ""
            if let dt = forcast.dt {
                let unixCD = Date(timeIntervalSince1970: TimeInterval(dt))
                let df = DateFormatter()
                df.dateFormat = "EEEE"
                dateString = df.string(from: unixCD)
            }
            
            return WeatherDailyData(iconName: iconName, dateName: dateString, weatherType: type, tempMin: minTemp, tempMax: maxTemp)
        }
        self.dailyData = daysData
        tableView.reloadData()
    }
    
    
    func setupTableView(){
        tableView.delegate = self
        tableView.dataSource = self
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dailyData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: WeatherCell.id, for: indexPath) as? WeatherCell {
            
            let day = dailyData[indexPath.row]
            cell.configre(day)
            return cell
        }
        return UITableViewCell()
    }
}

extension ViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locationValue = manager.location?.coordinate else { return }
        currentLocation = locationValue
        let loc = Location(lat: currentLocation.latitude, long: currentLocation.longitude)
        loadWeather(for: loc)
    }
}
