//
//  WeatherAPI.swift
//  Sunny Days
//
//  Created by Anas Almomany on 6/7/20.
//  Copyright © 2020 plaster. All rights reserved.
//

import Foundation
import Alamofire

struct Location {
    static let dumpData = Location(lat: 51.86888, long: 23.6074826)
    
    let lat: Double
    let long: Double
}

let iconsPath = "http://openweathermap.org/img/wn/##@2x.png"

struct WeatherApiRequest {
    private let appId: String = "16b283e73d446233a352408c2fe90f53"
    var location: Location
    
    var weatherUrl: String {
        return "http://api.openweathermap.org/data/2.5/weather?lat=\(location.lat)&lon=\(location.long)&units=metric&appid=\(appId)"
    }
    
    var dailyForcastUrl: String {
        return "https://samples.openweathermap.org/data/2.5/forecast/daily?lat=\(location.lat)&lon=\(location.long)&cnt=10&appid=\(appId)"
    }
}

class WeatherApi {
    static var shared = WeatherApi()
    
    func callWeatherApi(location: Location, completion: @escaping ((WeatherDetailsData?) -> ())){
        let request = WeatherApiRequest(location: location)
        AF.request(request.weatherUrl).response { (response) in
            guard let data = response.data else { return }
            do {
                let decoder = JSONDecoder()
                let currentW = try decoder.decode(WeatherDetailsData.self, from: data)
                completion(currentW)
            } catch let err {
                print(err)
                completion(nil)
            }
        }
    }
    
    func callDailyForcastApi(location: Location, completion: @escaping ((WeatherForcastData?) -> ())){
        let request = WeatherApiRequest(location: location)
        AF.request(request.dailyForcastUrl).response { (response) in
            guard let data = response.data else { return }
            do {
                let decoder = JSONDecoder()
                let forcasts = try decoder.decode(WeatherForcastData.self, from: data)
                completion(forcasts)
            } catch let err {
                print(err)
                completion(nil)
            }
        }
    }
}
