//
//  ViewController.swift
//  welcomeApp
//
//  Created by Anas Almomany on 4/15/20.
//  Copyright © 2020 test. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var titleImageView: UIImageView!
    
    @IBOutlet weak var backroundImageView: UIImageView!
    
    @IBOutlet weak var showWelcomeButton: UIButton!
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        titleImageView.isHidden = false
        backroundImageView.isHidden = false
        showWelcomeButton.isHidden = true
    }
    
}

