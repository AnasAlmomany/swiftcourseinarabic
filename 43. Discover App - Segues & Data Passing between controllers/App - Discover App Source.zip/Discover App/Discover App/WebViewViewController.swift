//
//  WebViewViewController.swift
//  Discover App
//
//  Created by Anas Almomany on 5/28/20.
//  Copyright © 2020 plaster. All rights reserved.
//

import UIKit
import WebKit

class WebViewViewController: UIViewController {
    @IBOutlet weak var webView: WKWebView!
    
    var entity: Entity!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let keyWord = entity.title
        let link = "https://www.pexels.com/search/\(keyWord)/"
        if let url = URL(string: link) {
            webView.load(URLRequest(url: url))
        }
    }
}
