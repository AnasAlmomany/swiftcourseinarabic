//
//  ViewController.swift
//  Discover App
//
//  Created by Anas Almomany on 5/27/20.
//  Copyright © 2020 plaster. All rights reserved.
//

import UIKit

class DiscoverViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
    
    lazy var entities: [Entity] = {
        var arr: [Entity] = []
        arr.append(Entity(image: UIImage(named: "cats"), title: "cats"))
        arr.append(Entity(image: UIImage(named: "company"), title: "company"))
        arr.append(Entity(image: UIImage(named: "converse-all-star"), title: "converse-all-star"))
        arr.append(Entity(image: UIImage(named: "dog"), title: "dog"))
        arr.append(Entity(image: UIImage(named: "hiking"), title: "hiking"))
        arr.append(Entity(image: UIImage(named: "planing"), title: "planing"))
        arr.append(Entity(image: UIImage(named: "sleeping"), title: "sleeping"))
        arr.append(Entity(image: UIImage(named: "sunglasses"), title: "sunglasses"))
        arr.append(Entity(image: UIImage(named: "waves"), title: "waves"))
        return arr
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? WebViewViewController, let entity = sender as? Entity {
            destination.entity = entity
        }
    }
    
    @IBAction func goTapped(_ sender: UIButton) {
        if let text = searchTextField.text, !text.isEmpty {
            let entity = Entity(image: nil, title: text)
            performSegue(withIdentifier: "MyBridge", sender: entity)
        }
    }
}

// Table view
extension DiscoverViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return entities.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: EntityCell.id, for: indexPath) as? EntityCell {
            cell.configre(entity: entities[indexPath.row])
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let entity = entities[indexPath.row]
        performSegue(withIdentifier: "MyBridge", sender: entity)
    }
}
