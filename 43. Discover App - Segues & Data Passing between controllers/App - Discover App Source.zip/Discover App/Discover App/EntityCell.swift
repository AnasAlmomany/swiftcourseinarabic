//
//  EntityCell.swift
//  Discover App
//
//  Created by Anas Almomany on 5/27/20.
//  Copyright © 2020 plaster. All rights reserved.
//

import UIKit

struct Entity {
    let image: UIImage?
    let title: String
}

class EntityCell: UITableViewCell {
    static var id = "EntityCell"
    
    @IBOutlet weak var entityImgView: UIImageView!
    @IBOutlet weak var entityTitleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setupImageViewUI()
    }
    
    func setupImageViewUI(){
        entityImgView.backgroundColor = .lightGray
        entityImgView.layer.cornerRadius = entityImgView.frame.height/2
        
        entityImgView.layer.borderWidth = 1
        entityImgView.layer.borderColor = UIColor.green.cgColor
    }
    
    func configre(entity: Entity){
        entityImgView.image = entity.image
        entityTitleLabel.text = entity.title
    }
}
