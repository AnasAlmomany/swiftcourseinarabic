import UIKit


var employeeSalary = 100.0
var employeeSalary2 = 200.0
var employeeSalary3 = 150.0

var employeesSalaries = [employeeSalary, employeeSalary2, employeeSalary3]

var emplyeesName = [ "Ahamd", "Anas", "Moe"]

print(emplyeesName)

emplyeesName.append("Belal")

print(emplyeesName.count)

emplyeesName.append(contentsOf: ["A", "B"])

print(emplyeesName[1])

var birdsNames: [String] = []
var birdsNames2 = [String]()
var birdsNames3: Array<String> = [String]()

