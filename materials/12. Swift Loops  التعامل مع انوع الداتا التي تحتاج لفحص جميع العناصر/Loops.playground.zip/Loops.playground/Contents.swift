import UIKit

var employeeSal1 = 100.0
var employeeSal2 = 150.0
var employeeSal3 = 100.0

// Bad way
employeeSal1 = employeeSal1 + (employeeSal1 * 0.10)
employeeSal2 = employeeSal2 + (employeeSal2 * 0.10)
employeeSal3 = employeeSal3 + (employeeSal3 * 0.10)

var salaries = [100.0, 150.0, 100.0]

salaries[0] = salaries[0] + ( salaries[0] * 0.10)
salaries[1] = salaries[1] + ( salaries[1] * 0.10)
salaries[2] = salaries[2] + ( salaries[2] * 0.10)

// While Loop : atleast 1 excecution in run time
var index = 0 // 0 1 2
repeat {
    salaries[index] = salaries[index] + ( salaries[index] * 0.10)
    index += 1
} while (index < salaries.count)

// For in
for x in 0..<salaries.count {
   salaries[x] = salaries[x] + (salaries[x] * 0.10)
}

// For Each (hint each element/item)
for salary in salaries {
    print(salary + (salary * 0.10))
}
