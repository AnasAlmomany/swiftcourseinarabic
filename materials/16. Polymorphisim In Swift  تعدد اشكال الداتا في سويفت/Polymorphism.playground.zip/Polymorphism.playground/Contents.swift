import UIKit

class Shape {
    var area: Double = 0
    
    func calculateArea(valA: Double, valB: Double){
        // to be edited
    }
}

class Triangle: Shape {
    override func calculateArea(valA: Double, valB: Double) {
        area = (valA * valB) / 2
    }
}

class Rectangle: Shape {
    override func calculateArea(valA: Double, valB: Double) {
        area = valA * valB
    }
}

