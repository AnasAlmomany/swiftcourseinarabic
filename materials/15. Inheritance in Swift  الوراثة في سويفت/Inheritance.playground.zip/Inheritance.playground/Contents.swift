import UIKit

class Vehicle {
    var tires = 4
    var speed = 80
    
    init() {
        
    }
    
    func drive(){
        print("I'am Vehicle Speed = \(speed)")
    }
    
    func brake(){
        
    }
}

class Truck: Vehicle {  /// class SubClass: ParentClass { }
    override init() {
        super.init()
        speed = 30
    }
    
    override func drive() {
        print("Iam truck my speed is \(speed)")
    }
}

class RacingCar: Vehicle {
    override init() {
        super.init()
        speed = 130
    }
    
    override func drive() {
        print("I'am speede my speed is \(speed)")
    }
    
    override func brake() {
        print("Almonuim braking system")
    }
}

var truck = Truck()
truck.drive()

var speede = RacingCar()
speede.drive()

