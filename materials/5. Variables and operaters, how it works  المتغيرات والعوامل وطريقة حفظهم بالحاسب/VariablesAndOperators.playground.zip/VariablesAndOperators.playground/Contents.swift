import UIKit

var msg = "Hello, playground"

// Operators:
// 1- unary:

var iWillCookToday = true
iWillCookToday = !iWillCookToday

// 2- binary : var msg = "Hello, playground"
// 3- ternary :

var iFeelGood = true
iFeelGood = iWillCookToday ? true : false

var salary = 40 //$
var bankMsg = salary >= 50 ? "You are fine for now!" : "You are broke!"

