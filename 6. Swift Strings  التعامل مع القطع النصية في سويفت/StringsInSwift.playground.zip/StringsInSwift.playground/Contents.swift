import UIKit

var str = "Hello, playground "

var firtName = "Anas"
var lastName = "Almomany"

var fullName = firtName + " " + lastName
var fullName2 = "\(firtName) \(lastName) age is \(26)"

fullName.append(" is great")
fullName.count
fullName.capitalized // prop
fullName.uppercased() // func 
fullName.lowercased()

if fullName.contains("Anas") || fullName.contains("Almomany") {
    fullName.replacingOccurrences(of: "great", with: "good")
}
